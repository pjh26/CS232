/**

*/

#include "SPShell.h"

using namespace std;

int main() {
	SPShell shell = SPShell();
	shell.run();
}
